package com.db.tradestorage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradestorageApplicationTests {

	@Test
	void contextLoads() {
	}

}
